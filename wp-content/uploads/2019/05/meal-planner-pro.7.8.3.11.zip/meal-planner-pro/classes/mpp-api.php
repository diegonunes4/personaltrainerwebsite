<?php
/**
 * Created by PhpStorm.
 * User: hoangle
 * Date: 4/19/18
 * Time: 18:02
 */

require_once plugin_dir_path(__FILE__) . 'wp-async-request.php';
require_once plugin_dir_path(__FILE__) . 'wp-background-process.php';
require_once plugin_dir_path(__FILE__) . 'mpp-api-request.php';
require_once plugin_dir_path(__FILE__) . 'mpp-api-process.php';